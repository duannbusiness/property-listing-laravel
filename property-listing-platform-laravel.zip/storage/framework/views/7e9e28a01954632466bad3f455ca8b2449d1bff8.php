
<script src="<?php echo e(asset('assets/js/jquery-3.3.1.min.js' )); ?>"></script>
<script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js' )); ?>"></script>
<script src="<?php echo e(asset('assets/js/lightbox.min.js' )); ?>"></script>
<script src="<?php echo e(asset('assets/js/main.js' )); ?>"></script><?php /**PATH D:\GitHUBPC\property-listing-platform-laravel\resources\views/site/includes/_scripts.blade.php ENDPATH**/ ?>