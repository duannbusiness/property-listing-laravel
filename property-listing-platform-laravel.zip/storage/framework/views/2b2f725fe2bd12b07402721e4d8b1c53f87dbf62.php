<!-- Footer -->

<footer class="footer text-center">
    All Rights Reserved
</footer><?php /**PATH D:\GitHUBPC\property-listing-platform-laravel\resources\views/admin/includes/_footer.blade.php ENDPATH**/ ?>