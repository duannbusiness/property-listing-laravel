

<?php $__env->startSection('content'); ?>
 
 <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <!-- Row -->
                <div class="row">
                    <!-- Column -->
                    <div class="col-lg-4 col-xlg-3 col-md-5">
                        <div class="card">
                            <div class="card-body">
                            <center class="m-t-30">
                                    <h4 class="card-title m-t-10"><?php echo e($inquiry ->user-> username); ?></h4>

                            </center>
                            </div>
                            <div>
                                <hr> </div>
                            <div class="card-body"> <small class="text-muted">Email address </small>
                                <h6><?php echo e($inquiry -> email); ?></h6> <small class="text-muted p-t-30 db">Phone</small>
                                <h6><?php echo e($inquiry -> contact_number); ?></h6> 
                                <br/>
                            </div>
                        </div>
                    </div>
                    <!-- Column -->
                    <!-- Column -->
                    <div class="col-lg-8 col-xlg-9 col-md-7">
                        <div class="card">
                            <div class="card-body">
                                    <div class="form-group">
                                        <label class="col-md-12">Listing :</label>
                                        <div class="col-md-12">
                                            <td><?php echo e($inquiry -> listing -> title); ?></td>
                                            <td class="mr-5">
                                                <a href="<?php echo e(route('single.listing', $inquiry -> listing -> id )); ?>"><span class="btn btn-sm btn-rounded btn-success">View</span></a>
                                            </td>
                                        </div>
                                    </div>
                            </div>
                        <div class="card">
                            <div class="card-body">
                                    <div class="form-group">
                                        <label class="col-md-12">Message :</label>
                                        <div class="col-md-12">
                                            <?php echo e($inquiry -> description); ?>

                                        </div>
                                    </div>
                            </div>
                        </div>
                    </div>
                    <!-- Column -->
                </div>

                <!-- Row -->
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Right sidebar -->
                <!-- ============================================================== -->
                <!-- .right-sidebar -->
                <!-- ============================================================== -->
                <!-- End Right sidebar -->
                <!-- ============================================================== -->
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\GitHUBPC\property-listing-platform-laravel\resources\views/admin/layouts/listing-inquiry/single-inquiry.blade.php ENDPATH**/ ?>